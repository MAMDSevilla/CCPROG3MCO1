public enum AccesswayType {
    ENTRANCE,
    EXIT
}