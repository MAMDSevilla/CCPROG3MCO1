public enum DispType {
    TABLE,
    REFRIGERATOR,
    CHILLED_COUNTER,
    SHELF
}