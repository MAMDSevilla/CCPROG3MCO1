public class Cart extends Equipment {
    public Cart() {
        super("Cart", 30);
    }
}
