public abstract class Service {
    public abstract void interact(Shopper shopper, Map map);
}