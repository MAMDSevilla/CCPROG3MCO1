public enum EquipmentType {
    CART,
    BASKET
}