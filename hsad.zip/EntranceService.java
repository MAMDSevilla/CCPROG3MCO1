public class EntranceService extends Service {
    @Override
    public void interact(Shopper shopper, Map map) {
        // None
    }
}