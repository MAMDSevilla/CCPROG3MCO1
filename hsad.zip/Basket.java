public class Basket extends Equipment {
    public Basket() {
        super("Basket", 5);
    }
}
